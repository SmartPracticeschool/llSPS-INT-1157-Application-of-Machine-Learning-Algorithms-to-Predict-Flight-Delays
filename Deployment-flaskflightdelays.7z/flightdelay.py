

import numpy as np
import pandas as pd
import datetime
import matplotlib.pyplot as plt

df=pd.read_csv('airports.csv')

df_use=pd.read_csv('flights.csv')
df=df_use.sample(n=100000).copy()
del df_use

#df.head()

df.groupby('DEPARTURE_DELAY').size()

df['OUTPUT_LABEL']=(df.DEPARTURE_DELAY>=15).astype(int)

'''plt.scatter(df['SCHEDULED_DEPARTURE'],df['OUTPUT_LABEL'])
plt.xlabel('SCHEDULED_DEPARTURE')
plt.ylabel('OUTPUT_LABEL')
plt.title('Scatter plot on flight dataset')

plt.scatter(df['SCHEDULED_TIME'],df['OUTPUT_LABEL'])
plt.xlabel('SCHEDULED_TIME')
plt.ylabel('OUTPUT_LABEL')
plt.title('Scatter plot on flight dataset')

plt.scatter(df['MONTH'],df['OUTPUT_LABEL'])
plt.xlabel('MONTH')
plt.ylabel('OUTPUT_LABEL')
plt.title('Scatter plot on flight dataset')

plt.scatter(df['DAY_OF_WEEK'],df['OUTPUT_LABEL'])
plt.xlabel('DAY_OF_WEEK')
plt.ylabel('OUTPUT_LABEL')
plt.title('Scatter plot on flight dataset')'''

def cal_prevalence(y_actual):
    return(sum(y_actual)/len(y_actual))

print('Prevalence:%.3f'%cal_prevalence(df['OUTPUT_LABEL'].values))

df_airports=pd.read_csv('airports.csv')
#df_airports

df.loc[~df.ORIGIN_AIRPORT.isin(df_airports.IATA_CODE.values),'ORIGIN_AIRPORT']='OTHERS'
df.loc[~df.DESTINATION_AIRPORT.isin(df_airports.IATA_CODE.values),'DESTINATION_AIRPORT']='OTHERS'

df=df.drop(columns=['TAXI_OUT', 'TAXI_IN', 'WHEELS_ON', 'WHEELS_OFF', 'YEAR',  'AIR_SYSTEM_DELAY','ELAPSED_TIME','CANCELLED',
                       'SECURITY_DELAY', 'AIRLINE_DELAY', 'LATE_AIRCRAFT_DELAY',
                       'WEATHER_DELAY', 'DIVERTED', 'CANCELLATION_REASON',
                     'TAIL_NUMBER', 'AIR_TIME'])

df['AIRLINE'].replace(['UA','AA','US','F9','B6','OO','AS','NK','WN','DL','EV','HA','MQ','VX'],[1,2,3,4,5,6,7,8,9,10,11,12,13,14],inplace=True)
     

df['ORIGIN_AIRPORT'].replace(['ABE','ABI','ABQ','ABR','ABY','ACK','ACT','ACV','ACY','ADK','ADQ','AEX','AGS','AKN','ALB','ALO','AMA','ANC','APN','ASE','ATL','ATW','AUS','AVL','AVP','AZO','BDL','BET','BFL','BGM','BGR','BHM','BIL','BIS','BJI','BLI','BMI','BNA','BOI','BOS','BPT','BQK','BQN','BRD','BRO','BRW','BTM','BTR','BTV','BUF','BUR','BWI','BZN','CAE','CAK','CDC','CDV','CEC','CHA','CHO','CHS','CID','CIU','CLD','CLE','CLL','CLT','CMH','CMI','CMX','CNY','COD','COS','COU','CPR','CRP','CRW','CSG','CVG','CWA','DAB','DAL','DAY','DBQ','DCA','DEN','DFW','DHN','DIK','DLG','DLH','DRO','DSM','DTW','DVL','EAU','ECP','EGE','EKO','ELM','ELP','ERI','ESC','EUG','EVV','EWN','EWR','EYW','FAI','FAR','FAT','FAY','FCA','FLG','FLL','FNT','FSD','FSM','FWA','GCC','GCK','GEG','GFK','GGG','GJT','GNV','GPT','GRB','GRI','GRK','GRR','GSO','GSP','GST','GTF','GTR','GUC','GUM','HDN','HIB','HLN','HNL','HOB','HOU','HPN','HRL','HSV','HYA','HYS','IAD','IAG','IAH','ICT','IDA','ILG','ILM','IMT','IND','INL','ISN','ISP','ITH','ITO','JAC','JAN','JAX','JFK','JLN','JMS','JNU','KOA','KTN','LAN','LAR','LAS','LAW','LAX','LBB','LBE','LCH','LEX','LFT','LGA','LGB','LIH','LIT','LNK','LRD','LSE','LWS','MAF','MBS','MCI','MCO','MDT','MDW','MEI','MEM','MFE','MFR','MGM','MHK','MHT','MIA','MKE','MKG','MLB','MLI','MLU','MMH','MOB','MOT','MQT','MRY','MSN','MSO','MSP','MSY','MTJ','MVY','MYR','OAJ','OAK','OGG','OKC','OMA','OME','ONT','ORD','ORF','ORH','OTH','OTZ','PAH','PBG','PBI','PDX','PHF','PHL','PHX','PIA','PIB','PIH','PIT','PLN','PNS','PPG','PSC','PSE','PSG','PSP','PUB','PVD','PWM','RAP','RDD','RDM','RDU','RHI','RIC','RKS','RNO','ROA','ROC','ROW','RST','RSW','SAF','SAN','SAT','SAV','SBA','SBN','SBP','SCC','SCE','SDF','SEA','SFO','SGF','SGU','SHV','SIT','SJC','SJT','SJU','SLC','SMF','SMX','SNA','SPI','SPS','SRQ','STC','STL','STT','STX','SUN','SUX','SWF','SYR','TLH','TOL','TPA','TRI','TTN','TUL','TUS','TVC','TWF','TXK','TYR','TYS','UST','VEL','VLD','VPS','WRG','WYS','XNA','YAK','YUM','OTHERS'],[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323],inplace=True)

df['DESTINATION_AIRPORT'].replace(['ABE','ABI','ABQ','ABR','ABY','ACK','ACT','ACV','ACY','ADK','ADQ','AEX','AGS','AKN','ALB','ALO','AMA','ANC','APN','ASE','ATL','ATW','AUS','AVL','AVP','AZO','BDL','BET','BFL','BGM','BGR','BHM','BIL','BIS','BJI','BLI','BMI','BNA','BOI','BOS','BPT','BQK','BQN','BRD','BRO','BRW','BTM','BTR','BTV','BUF','BUR','BWI','BZN','CAE','CAK','CDC','CDV','CEC','CHA','CHO','CHS','CID','CIU','CLD','CLE','CLL','CLT','CMH','CMI','CMX','CNY','COD','COS','COU','CPR','CRP','CRW','CSG','CVG','CWA','DAB','DAL','DAY','DBQ','DCA','DEN','DFW','DHN','DIK','DLG','DLH','DRO','DSM','DTW','DVL','EAU','ECP','EGE','EKO','ELM','ELP','ERI','ESC','EUG','EVV','EWN','EWR','EYW','FAI','FAR','FAT','FAY','FCA','FLG','FLL','FNT','FSD','FSM','FWA','GCC','GCK','GEG','GFK','GGG','GJT','GNV','GPT','GRB','GRI','GRK','GRR','GSO','GSP','GST','GTF','GTR','GUC','GUM','HDN','HIB','HLN','HNL','HOB','HOU','HPN','HRL','HSV','HYA','HYS','IAD','IAG','IAH','ICT','IDA','ILG','ILM','IMT','IND','INL','ISN','ISP','ITH','ITO','JAC','JAN','JAX','JFK','JLN','JMS','JNU','KOA','KTN','LAN','LAR','LAS','LAW','LAX','LBB','LBE','LCH','LEX','LFT','LGA','LGB','LIH','LIT','LNK','LRD','LSE','LWS','MAF','MBS','MCI','MCO','MDT','MDW','MEI','MEM','MFE','MFR','MGM','MHK','MHT','MIA','MKE','MKG','MLB','MLI','MLU','MMH','MOB','MOT','MQT','MRY','MSN','MSO','MSP','MSY','MTJ','MVY','MYR','OAJ','OAK','OGG','OKC','OMA','OME','ONT','ORD','ORF','ORH','OTH','OTZ','PAH','PBG','PBI','PDX','PHF','PHL','PHX','PIA','PIB','PIH','PIT','PLN','PNS','PPG','PSC','PSE','PSG','PSP','PUB','PVD','PWM','RAP','RDD','RDM','RDU','RHI','RIC','RKS','RNO','ROA','ROC','ROW','RST','RSW','SAF','SAN','SAT','SAV','SBA','SBN','SBP','SCC','SCE','SDF','SEA','SFO','SGF','SGU','SHV','SIT','SJC','SJT','SJU','SLC','SMF','SMX','SNA','SPI','SPS','SRQ','STC','STL','STT','STX','SUN','SUX','SWF','SYR','TLH','TOL','TPA','TRI','TTN','TUL','TUS','TVC','TWF','TXK','TYR','TYS','UST','VEL','VLD','VPS','WRG','WYS','XNA','YAK','YUM','OTHERS'],[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323],inplace=True)



col_num=['SCHEDULED_DEPARTURE','SCHEDULED_TIME','FLIGHT_NUMBER','AIRLINE','ORIGIN_AIRPORT','DESTINATION_AIRPORT','DAY_OF_WEEK','MONTH']


df_data=df[col_num+['OUTPUT_LABEL']]



x=df_data.iloc[:,0:8]
y=df_data.iloc[:,8]





#Splitting the dataset into Training set and Test set
from sklearn import model_selection, neighbors
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.2)

y_train=y_train.astype('int')
#y_train

y_test=y_test.astype('int')
#y_test

# Perform Logistic Regression
from sklearn.linear_model.logistic import LogisticRegression

lr =LogisticRegression(random_state =0)

lr.fit(x_train, y_train)

#Predicting on test and train data
lr_y_test =lr.predict(x_test)
#lr_y_test

lr_y_train = lr.predict(x_train)
#lr_y_train

#Accuracy score on Test and Train
from sklearn.metrics import accuracy_score, recall_score, roc_auc_score, confusion_matrix

print("\nAccuracy score: %f" %(accuracy_score(y_test,lr_y_test) * 100))
print("Recall score : %f" %(recall_score(y_test, lr_y_test) * 100))
print("ROC score : %f\n" %(roc_auc_score(y_test, lr_y_test) * 100))
print(confusion_matrix(y_test, lr_y_test)) 

from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
x_train_std = scaler.fit_transform(x_train)
x_test_std = scaler.transform(x_test)
from sklearn.model_selection import cross_val_score, cross_val_predict
lr_acc = cross_val_score(lr, x_train_std, y_train, cv=3, scoring='accuracy', n_jobs=-1)
lr_proba = cross_val_predict(lr, x_train_std, y_train, cv=3, method='predict_proba')
lr_scores = lr_proba[:, 1]

#lr_acc

lr_accu_train= accuracy_score(y_train,lr_y_train)  #train 98--rs=50  
#lr_accu_train

#Evaluate model
'''from sklearn.metrics import roc_auc_score
from sklearn.metrics import roc_curve
def ROC_curve(title, y_train, scores, label=None):
    
    # calculate the ROC score
    fpr, tpr, thresholds = roc_curve(y_train, scores)
    print('AUC Score ({}): {:.2f} '.format(title, roc_auc_score(y_train, scores)))

    # plot the ROC curve
    plt.figure(figsize=(8,6))
    plt.plot(fpr, tpr, linewidth=2, label=label, color='b')
    plt.xlabel('False Positive Rate', fontsize=16)
    plt.ylabel('True Positive Rate', fontsize=16)
    plt.title('ROC Curve: {}'.format(title), fontsize=16)
    plt.show()

#Plot ROC Curve
ROC_curve('logistic regression', y_train, lr_scores)'''

#Precision score on Test and Train
from sklearn.metrics import precision_score

lr_precision_test =precision_score(y_test, lr_y_test, average='weighted')  
print(lr_precision_test)
lr_precision_train =precision_score(y_train, lr_y_train, average='weighted')
print(lr_precision_train)

#Recall score on Test and Train
from sklearn.metrics import recall_score
lr_recall_test=recall_score(y_test,lr_y_test, average='weighted' )
print(lr_recall_test)
lr_recall_train=recall_score(y_train,lr_y_train, average='weighted' )
print(lr_recall_train)

import pickle
pickle.dump(lr, open('model.pkl','wb'))

model = pickle.load(open('model.pkl','rb'))
print(lr.predict([[1335,240.0,653,6,2,6,86,277]]))
#Decision Tree Classifier
'''from sklearn.tree import DecisionTreeClassifier

dtc = DecisionTreeClassifier()
dtc.fit(x_train,y_train)


#Predicting on test and train data
dtc_y_test =dtc.predict(x_test)
dtc_y_test

dtc_y_train = dtc.predict(x_train)
dtc_y_train


#Build confusion matrix on Test and Train
from sklearn.metrics import confusion_matrix
dtc_cm_test = confusion_matrix(y_test, dtc_y_test)
dtc_cm_test

from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
x_train_std = scaler.fit_transform(x_train)
x_test_std = scaler.transform(x_test)
from sklearn.model_selection import cross_val_score, cross_val_predict
dtc_acc = cross_val_score(dtc, x_train_std, y_train, cv=3, scoring='accuracy', n_jobs=-1)
dtc_proba = cross_val_predict(dtc, x_train_std, y_train, cv=3, method='predict_proba')
dtc_scores = dtc_proba[:, 1]

dtc_acc

#Accuracy score on Test and Train
from sklearn.metrics import accuracy_score
dtc_accu_test= accuracy_score(y_test,dtc_y_test)
dtc_accu_test

dtc_accu_train= accuracy_score(y_train,dtc_y_train)    
dtc_accu_train

#Precision score on Test and Train
from sklearn.metrics import precision_score

dtc_precision_test =precision_score(y_test, dtc_y_test, average='weighted')  
print(dtc_precision_test)
dtc_precision_train =precision_score(y_train, dtc_y_train, average='weighted')
print(dtc_precision_train)

#Recall score on Test and Train
from sklearn.metrics import recall_score
dtc_recall_test=recall_score(y_test,dtc_y_test, average='weighted' )
print(dtc_recall_test)
dtc_recall_train=recall_score(y_train,dtc_y_train, average='weighted' )
print(dtc_recall_train)

#Plot ROC Curve
ROC_curve('decision tree classifier', y_train, dtc_scores)

from sklearn.linear_model import SGDClassifier
sgdc=SGDClassifier(loss='log',alpha=0.1)
sgdc.fit(x_train,y_train)

sgdc_y_test =sgdc.predict(x_test)
sgdc_y_test

#Predicting on test and train data
sgdc_y_test =sgdc.predict(x_test)
sgdc_y_test

sgdc_y_train = sgdc.predict(x_train)
sgdc_y_train


#Build confusion matrix on Test and Train
from sklearn.metrics import confusion_matrix
sgdc_cm_test = confusion_matrix(y_test, dtc_y_test)
sgdc_cm_test

from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
x_train_std = scaler.fit_transform(x_train)
x_test_std = scaler.transform(x_test)
from sklearn.model_selection import cross_val_score, cross_val_predict
sgdc_acc = cross_val_score(sgdc, x_train_std, y_train, cv=3, scoring='accuracy', n_jobs=-1)
sgdc_proba = cross_val_predict(sgdc, x_train_std, y_train, cv=3, method='predict_proba')
sgdc_scores = sgdc_proba[:, 1]

#Accuracy score on Test and Train
from sklearn.metrics import accuracy_score
sgdc_accu_test= accuracy_score(y_test,dtc_y_test)
sgdc_accu_test

#Precision score on Test and Train
from sklearn.metrics import precision_score

sgdc_precision_test =precision_score(y_test, dtc_y_test, average='weighted')  
print(sgdc_precision_test)
sgdc_precision_train =precision_score(y_train, dtc_y_train, average='weighted')
print(sgdc_precision_train)

#Recall score on Test and Train
from sklearn.metrics import recall_score
sgdc_recall_test=recall_score(y_test,dtc_y_test, average='weighted' )
print(sgdc_recall_test)
sgdc_recall_train=recall_score(y_train,dtc_y_train, average='weighted' )
print(sgdc_recall_train)

#Plot ROC Curve
ROC_curve('decision tree classifier', y_train, sgdc_scores)

from sklearn.ensemble import RandomForestClassifier
rf=RandomForestClassifier(max_depth=6)
rf.fit(x_train,y_train)

#Predicting on test and train data
rf_y_test =rf.predict(x_test)
rf_y_test

rf_y_train = rf.predict(x_train)
rf_y_train


#Build confusion matrix on Test and Train
from sklearn.metrics import confusion_matrix
rf_cm_test = confusion_matrix(y_test, rf_y_test)
rf_cm_test

from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
x_train_std = scaler.fit_transform(x_train)
x_test_std = scaler.transform(x_test)
from sklearn.model_selection import cross_val_score, cross_val_predict
rf_acc = cross_val_score(rf, x_train_std, y_train, cv=3, scoring='accuracy', n_jobs=-1)
rf_proba = cross_val_predict(rf, x_train_std, y_train, cv=3, method='predict_proba')
rf_scores = dtc_proba[:, 1]

#Accuracy score on Test and Train
from sklearn.metrics import accuracy_score
rf_accu_test= accuracy_score(y_test,dtc_y_test)
rf_accu_test

#Precision score on Test and Train
from sklearn.metrics import precision_score

rf_precision_test =precision_score(y_test, dtc_y_test, average='weighted')  
print(rf_precision_test)
rf_precision_train =precision_score(y_train, dtc_y_train, average='weighted')
print(rf_precision_train)

#Recall score on Test and Train
from sklearn.metrics import recall_score
rf_recall_test=recall_score(y_test,dtc_y_test, average='weighted' )
print(rf_recall_test)
rf_recall_train=recall_score(y_train,dtc_y_train, average='weighted' )
print(rf_recall_train)

#Plot ROC Curve
ROC_curve('decision tree classifier', y_train, rf_scores)'''

