import requests

url = 'http://localhost:5000/predict_api'
r = requests.post(url,json={'SCHEDULE_DEPARTURE':1335, 'SCHEDULE_TIME':240.0, 'FLIGHT_NUMBER':653,'MONTH':6,'DAY_OF_WEEK':2,'AIRLINE':6,'ORIGIN_AIRPORT':86,'DESTINATION_AIRPORT':277})

print(r.json())
